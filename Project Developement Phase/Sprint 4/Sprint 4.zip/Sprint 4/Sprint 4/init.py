import random

randomnumber = random.randint(0,100)
id =0
hello =0